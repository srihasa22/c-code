#ifndef CUSTOMER_H
#define CUSTOMER_H

#define MAX_NAME_LENGTH 50
#define MAX_ADDRESS_LENGTH 100
#define MAX_EMAIL_LENGTH 50
#define MAX_PHONE_LENGTH 15

#include <stdlib.h> // Include necessary for malloc and calloc

// Structure to represent a customer
struct customer {
    int id;  // Unique identifier for the customer
    char *name;   // Dynamic allocation for name
    char *address; // Dynamic allocation for address
    char *email;   // Dynamic allocation for email
    char *phone;   // Dynamic allocation for phone
    // You can add more fields as needed
};

// Function to initialize a customer structure
struct customer *create_customer(int id) {
    struct customer *new_customer = malloc(sizeof(struct customer));
    if (new_customer == NULL) {
        return NULL; // Allocation failed
    }
    // Allocate memory for each string field
    new_customer->name = calloc(MAX_NAME_LENGTH, sizeof(char));
    new_customer->address = calloc(MAX_ADDRESS_LENGTH, sizeof(char));
    new_customer->email = calloc(MAX_EMAIL_LENGTH, sizeof(char));
    new_customer->phone = calloc(MAX_PHONE_LENGTH, sizeof(char));
    // Initialize other fields
    new_customer->id = id;
    return new_customer;
}

// Function to free memory allocated for a customer structure
void free_customer(struct customer *c) {
    free(c->name);
    free(c->address);
    free(c->email);
    free(c->phone
