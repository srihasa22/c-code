#ifndef ITEMS_H
#define ITEMS_H

#define MAX_ITEM_NAME_LENGTH 50

#include <stdlib.h> // Include necessary for malloc and calloc

// Structure to represent an item
struct item {
    int id;                         // Unique identifier for the item
    char *itemName;                 // Dynamic allocation for itemName
    int price;                      // Price of the item
};

// Function to initialize an item structure
struct item *create_item(int id, const char *name, int price) {
    struct item *new_item = malloc(sizeof(struct item));
    if (new_item == NULL) {
        return NULL; // Allocation failed
    }
    // Allocate memory for itemName
    new_item->itemName = calloc(MAX_ITEM_NAME_LENGTH, sizeof(char));
    if (new_item->itemName == NULL) {
        free(new_item);
        return NULL; // Allocation failed
    }
    // Copy the name into itemName
    strncpy(new_item->itemName, name, MAX_ITEM_NAME_LENGTH - 1);
    new_item->id = id;
    new_item->price = price;
    return new_item;
}

// Function to free memory allocated for an item structure
void free_item(struct item *i) {
    free(i->itemName);
    free(i);
}

#endif
